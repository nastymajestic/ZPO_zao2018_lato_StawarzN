package lab02;

public class Recursion {
	
	public static void rysujCyfry(int razy, int poziom)
	{
		for(int j = 0; j <= razy; j++)
		{
			System.out.print(j);
			
			for(int i = 0; i < (Math.pow(2, poziom-1)-1); i++)
			{
				System.out.print(" ");
			}
		}

		System.out.print("\n");
	}
	
	public static void rysujSpacjeiKreske(int razy, int poziom)
	{	
		if(poziom > 0)
		{ 
			for(int j = 0; j <= razy; j++)
			{				
				System.out.print("|");
				
				for(int i = 0; i < (Math.pow(2, poziom-1)-1); i++)
				{
					System.out.print(" ");
				}
			}
	
			System.out.print("\n");
			rysujSpacjeiKreske(razy * 2, poziom-1);
		}
	}
	
	public static void rysujWszystko(int razy, int poziom)
	{
		rysujCyfry(razy, poziom);
		rysujSpacjeiKreske(razy, poziom);
	}
	
	public static void main(String[] args) 
	{
		rysujWszystko(2,6);
	}
}
